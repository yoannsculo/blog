#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

#include <SDL/SDL.h>

// Biblioth�ques wiimote
#include "wiimote.h"
#include "wiimote_api.h"

#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define closesocket(s) close (s)
#define PORT 2000

typedef int SOCKET;
typedef struct sockaddr_in SOCKADDR_IN;
typedef struct sockaddr SOCKADDR;

int main (int argc, char* args[])
{
		struct sockaddr_in socket_adresse;
		struct sockaddr_in socket_adresse_client;
	
		SDL_Surface *ecran = NULL;
		SDL_Event event;
		SDL_Joystick *joystick = NULL;

		SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK);
		SDL_EnableKeyRepeat(100, 10);

    	ecran = SDL_SetVideoMode(200, 100, 32, SDL_HWSURFACE | SDL_RESIZABLE);
    	SDL_WM_SetCaption("Gestion des �v�nements en SDL", NULL);

		joystick = SDL_JoystickOpen(0);

		int serveursocket;
		int client=0;
		char buffer[32];
		
		int controle_mode = atoi(args[1]);
		if (controle_mode<1) controle_mode=1;

 		serveursocket = socket(PF_INET, SOCK_STREAM, 0);
      
		/* Si la socket est valide */
		if(serveursocket != INVALID_SOCKET)
		{

	 		printf("La socket %d est maintenant ouverte en mode TCP/IP\n", serveursocket);
		   
			/* Configuration */
		   socket_adresse.sin_port = htons(PORT);
		   socket_adresse.sin_addr.s_addr = htonl(INADDR_ANY);
		   //bzero(&(socket_adresse.sin_zero), 8);

		   int sock_err = bind(serveursocket, (struct sockaddr *)&socket_adresse, sizeof(socket_adresse));

		   if(sock_err != SOCKET_ERROR)
			{
				/* D�marrage du listage (mode server) */
				sock_err = listen(serveursocket, 1); // 10
				printf("Listage du port %d...\n", PORT);

            /* Si la socket fonctionne */
            if(sock_err != SOCKET_ERROR)
            {
					/* Attente pendant laquelle le client se connecte */
					printf("Patientez pendant que le client se connecte sur le port %d...\n", PORT);
					unsigned int long_adr = (unsigned int) sizeof(socket_adresse);
					client = accept (serveursocket, (struct sockaddr *)&socket_adresse_client,&long_adr);

					printf("Un client se connecte avec la socket %d de %s:%d\n", client, inet_ntoa(socket_adresse_client.sin_addr), htons(socket_adresse_client.sin_port));					

					char data[20];
	
					int continuer = 1;					
	
					switch (controle_mode)
					{
						// Clavier / Joystick
						case 1:
				
							while (continuer)					
							{
								SDL_WaitEvent(&event);

								switch(event.type)
								{
									case SDL_QUIT:
										continuer = 0;

										break;
								  	case SDL_KEYDOWN:
										
										switch (event.key.keysym.sym)
										{
											case SDLK_ESCAPE:
												sprintf(data, "QUIT");
												continuer = 0;
												break;

											case 274:
												sprintf(data, "ARRIERE");
												break;

											case 273:
												sprintf(data, "AVANT");
												break;

											case 275:
												sprintf(data, "DROITE");
												break;

											case 276:
												sprintf(data, "GAUCHE");
												break;

											case 282: // F1
												sprintf(data, "MODE1");
												break;

											case 283: // F2
												sprintf(data, "MODE2");
												break;

											case 284: // F3
												sprintf(data, "MODE3");
												break;

											case 32:
												sprintf(data, "KLAXON");
												break;
											default:
												// nothing
												break;
										}
										sock_err = send(client, data, sizeof(data), 0);
										if(sock_err == SOCKET_ERROR) printf("Erreur de transmission\n");
										
										break;
									case SDL_JOYBUTTONDOWN:
										
										switch (event.jbutton.button)
										{
											case 0:
												sprintf(data, "MODE1");
												break;
											case 1:
												sprintf(data, "MODE2");
												break;
											case 2:
												sprintf(data, "MODE3");
												break;
											case 7:
												sprintf(data, "KLAXON");
												break;
											default:
												// nothing
												break;
		
										}
										sock_err = send(client, data, sizeof(data), 0);
										if(sock_err == SOCKET_ERROR) printf("Erreur de transmission\n");							
										
										break;

									case SDL_JOYAXISMOTION:
										if (event.jaxis.axis == 0 && event.jaxis.value < -3200) sprintf(data, "GAUCHE");
										if (event.jaxis.axis == 0 && event.jaxis.value >  3200) sprintf(data, "DROITE");										
										if (event.jaxis.axis == 1 && event.jaxis.value < -3200) sprintf(data, "AVANT");
										if (event.jaxis.axis == 1 && event.jaxis.value >  3200) sprintf(data, "ARRIERE");
										
										sock_err = send(client, data, sizeof(data), 0);
										if(sock_err == SOCKET_ERROR) printf("Erreur de transmission\n");					
										
										break;
									default:
										// nothing
										break;
								}
							}
							break;

						// Wiimote
						case 2:
							printf("Wiimote : Appuyez sur 1 et 2 pour synchroniser la wiimote\n");
									
							char mac_wiimote[18] = "00:1F:32:86:ED:53"; // yoann
							//char mac_wiimote[18] = "00:22:D7:94:75:E4"; // robotik

							wiimote_t wiimote = WIIMOTE_INIT;
							wiimote_report_t report = WIIMOTE_REPORT_INIT;

							// Connexion � la wwimote
							
							if (wiimote_connect(&wiimote, mac_wiimote) < 0) {
								fprintf(stderr, "unable to open wiimote: %s\n", wiimote_get_error());
								exit(1);
							}
							printf("Manette de Wii connect�e avec succ�s.\n");
							
							//wiimote.led.one  = 0; // Eteint les DEL

							while (wiimote_is_open(&wiimote))
							{
								if (wiimote_update(&wiimote) < 0) {
									wiimote_disconnect(&wiimote);
									break;
								}
								
								if (wiimote.keys.home) {
									printf("Fermeture du serveur\n");
									break;
								}

								if (wiimote.keys.up) {								
 									sprintf(data, "AVANT");
								}
								if (wiimote.keys.left) {
									sprintf(data, "GAUCHE");
								}
								if (wiimote.keys.right)	{
									sprintf(data, "DROITE");
								}
								if (wiimote.keys.down) {
									sprintf(data, "ARRIERE");
								}
								if (wiimote.keys.a) {
									sprintf(data, "MODE3");
								}
								if (wiimote.keys.b) {
									sprintf(data, "KLAXON");
								}
								if (wiimote.keys.one)	{
									sprintf(data, "MODE1");
									wiimote.led.one = 1;
     							}
								if (wiimote.keys.two) {
									sprintf(data, "MODE2");
									wiimote.led.two = 1;
								}
								
								sock_err = send(client, data, sizeof(data), 0);
								if(sock_err == SOCKET_ERROR) printf("Erreur de transmission\n");
								
							}
							break;
					}
					SDL_JoystickClose(joystick);
					SDL_Quit();
					shutdown(serveursocket, 2);

            } else {
                printf("listen\n");
				}
			} else {
            printf("bind\n");
			}

			/* Fermeture de la socket client et de la socket serveur */
			printf("Fermeture de la socket client\n");
			closesocket(client);
			printf("Fermeture de la socket serveur\n");
			closesocket(serveursocket);
			printf("Fermeture du serveur termin�e\n");

      } else {
		        printf("socket\n");
		}
		return 0;
}
