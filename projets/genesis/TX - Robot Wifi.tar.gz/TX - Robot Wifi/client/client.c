#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
 
#include <sys/stat.h>
#include <stdarg.h>
#include <signal.h>

#include "sys/ioctl.h"
#include "asm/etraxgpio.h"
#include "time.h"

#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define closesocket(s) close (s)
#define PORT 2000

int tty_open(char* tty_dev);
void tty_printf(char *format, ...);
void termination_handler (int signum);
int stdin_init(void);

// SOCKETS
typedef int SOCKET;
typedef struct sockaddr_in SOCKADDR_IN;
typedef struct sockaddr SOCKADDR;

// SERIAL
struct termios stdin_saved_attributes;
struct termios tty_saved_attributes;
int tty_fd;

const int TAILLE_BUFFER=32;

int main (int argc, char* args[])
{
	
	// On commence par la connexion s�rie
	if (tty_open("/dev/ttyS0")<0) {
  		fprintf (stderr,"tty open error %s\n", strerror(errno));
		exit(EXIT_FAILURE);
   }

	if (stdin_init()<0) {
  		printf("stdin init error %s\n", strerror(errno));
	   exit(EXIT_FAILURE);
   } 

   if (signal (SIGINT, termination_handler) == SIG_IGN) signal (SIGINT, SIG_IGN);
   if (signal (SIGHUP, termination_handler) == SIG_IGN) signal (SIGHUP, SIG_IGN);
   if (signal (SIGTERM, termination_handler) == SIG_IGN) signal (SIGTERM, SIG_IGN);

	// Puis, connexion socket au PC embarqu�
	struct sockaddr_in socket_adresse;
	int clientsocket;

	clientsocket = socket(PF_INET, SOCK_STREAM, 0);
	socket_adresse.sin_family=AF_INET;
	socket_adresse.sin_port=htons(PORT);
	socket_adresse.sin_addr.s_addr = inet_addr(args[1]);
	bzero(&(socket_adresse.sin_zero), 8);

	int errconnect = connect(clientsocket, (struct sockaddr *)&socket_adresse, sizeof(socket_adresse));

	if(errconnect != SOCKET_ERROR)
	{
		printf("Connexion � %s sur le port %d\n", inet_ntoa(socket_adresse.sin_addr), htons(socket_adresse.sin_port));
		
		int touche=0;

		int etatHAUT=0;
		int etatBAS=0;
		int etatGAUCHE=0;
		int etatDROITE=0;

		int mode = 1;  // 1 : direction
							// 2 : camera

		int SERVOROUEGAUCHE  = 1; // 19
		int SERVOROUEDROITE  = 0; // 23
		int SERVOCAMERAHORIZ = 4;
		int SERVOCAMERAVERTI = 5;
		int SERVOPINCE 		= 8;

		int VITESSE = 750;
		int VITESSE_LENTE=0;

		int curseur_camera_horiz = 1775;
		int curseur_camera_verti = 1600;

		char rcvbuffer[TAILLE_BUFFER];

		tty_printf("#%dP1775%c",  SERVOCAMERAVERTI, 13);
		tty_printf("#%dP1600%c",  SERVOCAMERAHORIZ, 13);
		sleep(2);		

		while(1)
		{			
			
			int recu = recv(clientsocket, rcvbuffer, sizeof(rcvbuffer), 0);
			touche=atoi(rcvbuffer);

				printf("Touche:%d\n", touche);
				if (touche == 282) {
					mode = 1;
					printf("Mode direction\n");				
				}

				if (touche == 283) {
					mode = 2;
					printf("Mode camera\n");					
					tty_printf("#%dP0%c", SERVOROUEGAUCHE, 13);
					tty_printf("#%dP0%c",  SERVOROUEDROITE, 13);				
				}

				if (touche == 284) {
					mode = 3;
					printf("Mode pince\n");					
					tty_printf("#%dP0%c", SERVOROUEGAUCHE, 13);
					tty_printf("#%dP0%c",  SERVOROUEDROITE, 13);				
				}

				if (touche == 32) {
					int fd, i, iomask;					
					if ((fd=open("/dev/gpiog", O_RDWR)) <0) {
	
						printf("Erreur\n");
						exit(0);
					}
					iomask=1<<25;
					ioctl(fd,_IO(ETRAXGPIO_IOCTYPE,IO_SETBITS),iomask);
					sleep(1);
					ioctl(fd, _IO(ETRAXGPIO_IOCTYPE, IO_CLRBITS), iomask);		
				}
	
				if (touche    == 274) {
					printf("ARRIERE\n");
					if (mode == 1 ) {
						tty_printf("#%dP2000%c", SERVOROUEGAUCHE, 13);
						tty_printf("#%dP500%c",  SERVOROUEDROITE, 13);
					}
					else if (mode == 2 ) {
						if (curseur_camera_verti+30>=2400) curseur_camera_verti = 2400; 
						curseur_camera_verti += 30;						
						tty_printf("#%dP%d%c", SERVOCAMERAVERTI, curseur_camera_verti, 13);						
					}
					else if (mode == 3 ) {
						if (curseur_camera_verti+30>=2400) curseur_camera_verti = 2400; 
						curseur_camera_verti += 30;						
						tty_printf("#%dP2000%c", SERVOPINCE, 13);					
					}				
					
				}
				if (touche    == 273) {
					printf("AVANT\n");
					if (mode == 1 ) {
						tty_printf("#%dP500%c", SERVOROUEGAUCHE, 13);
						tty_printf("#%dP2000%c",  SERVOROUEDROITE, 13);
					}
					else if (mode == 2 ) {
						if (curseur_camera_verti-30>=2400) curseur_camera_verti = 2400; 
						curseur_camera_verti -= 30;						
						tty_printf("#%dP%d%c", SERVOCAMERAVERTI, curseur_camera_verti, 13);						
					}
					else if (mode == 3 ) {
						tty_printf("#%dP500%c", SERVOPINCE, 13);						
					}
				}

				if (touche    == 275) {
					
					printf("DROITE\n");
					if (mode == 1 ) {
						tty_printf("#%dP500%c", SERVOROUEGAUCHE, 13);
						tty_printf("#%dP500%c",  SERVOROUEDROITE, 13);
					}
					else if (mode == 2 ) {
						if (curseur_camera_horiz+30>=2400) curseur_camera_horiz = 2400; 
						curseur_camera_horiz += 30;						
						tty_printf("#%dP%d%c", SERVOCAMERAHORIZ, curseur_camera_horiz, 13);
					}
				}
				if (touche    == 276) {
					
					printf("GAUCHE\n");
					if (mode == 1 ) {
						tty_printf("#%dP2000%c", SERVOROUEGAUCHE, 13);
						tty_printf("#%dP2000%c",  SERVOROUEDROITE, 13);
					}
					else if (mode == 2 ) {
						if (curseur_camera_horiz-30<=900) curseur_camera_horiz = 900; 
						curseur_camera_horiz -= 30;						
						tty_printf("#%dP%d%c", SERVOCAMERAHORIZ, curseur_camera_horiz, 13);
					}
				}
		}


	} else {
		printf("Impossible de se connecter\n");
	}

	closesocket(clientsocket);
	return 0;
}

int tty_open(char* tty_dev) {
	struct termios new_attributes;

	tty_fd = open(tty_dev,O_RDWR| O_NOCTTY | O_NONBLOCK);
	
  if (tty_fd<0) {
  	return -1;
  } else {
	tcgetattr(tty_fd,&tty_saved_attributes);
	tcgetattr(tty_fd,&new_attributes);
	
	// Set the new attributes for the serial port
	// http://linux.about.com/library/cmd/blcmdl3_termios.htm
	// http://www.gnu.org/software/libc/manual/html_node/Low_002dLevel-I_002fO.html#Low_002dLevel-I_002fO
	
	// c_cflag
	new_attributes.c_cflag |= CREAD;		 	// Enable receiver
  	//new_attributes.c_cflag |= B9600;		 	// Set baud rate
  	new_attributes.c_cflag |= CS8;			 	// 8 data bit
  	
		// c_iflag
  	new_attributes.c_iflag |= IGNPAR;		 	// Ignore framing errors and parity errors. 
  	
		// c_lflag
  	new_attributes.c_lflag &= ~(ICANON); 	// DISABLE canonical mode. 
  																				// Disables the special characters EOF, EOL, EOL2, 
  																				// ERASE, KILL, LNEXT, REPRINT, STATUS, and WERASE, and buffers by lines.
  	new_attributes.c_lflag &= ~(ECHO);		// DISABLE this: Echo input characters.
  	new_attributes.c_lflag &= ~(ECHOE);		// DISABLE this: If ICANON is also set, the ERASE character erases the preceding input 
  																				// character, and WERASE erases the preceding word.
  	new_attributes.c_lflag &= ~(ISIG);		// DISABLE this: When any of the characters INTR, QUIT, SUSP, 
  																				// or DSUSP are received, generate the corresponding signal.
 	  
 	  new_attributes.c_cc[VMIN]=1;					// Minimum number of characters for non-canonical read.
	  new_attributes.c_cc[VTIME]=0;					// Timeout in deciseconds for non-canonical read.

    tcsetattr(tty_fd, TCSANOW, &new_attributes);
	}
  return tty_fd;
}

// Serial version of printf

void tty_printf(char *format, ...) {
  va_list argptr;
  char buffer[200];
  
  va_start(argptr,format);
  vsprintf(buffer,format,argptr);
  va_end(argptr);
  
  write(tty_fd,buffer,strlen(buffer));
}

void termination_handler (int signum) {
	tcsetattr(STDIN_FILENO,TCSANOW,&stdin_saved_attributes);
	if (tty_fd>0) tcsetattr (tty_fd,TCSANOW,&tty_saved_attributes);
	close(tty_fd);
	printf("Exit\n");
	exit(0);
}

int stdin_init(void) {
  struct termios tattr;

  // Make sure stdin is a terminal
	if (!isatty (STDIN_FILENO)) {
		fprintf (stderr,"stdin is not a terminal\n");
	  return -1;
	}

	// Save the terminal attributes so we can restore them later.
	tcgetattr (STDIN_FILENO, &stdin_saved_attributes);

  // Set the funny terminal modes. 
  tcgetattr (STDIN_FILENO, &tattr);
  tattr.c_lflag &= ~(ICANON | ECHO); /* Clear ICANON and ECHO. */
  tattr.c_cc[VMIN] = 0;
  tattr.c_cc[VTIME] = 0;
  tcsetattr (STDIN_FILENO, TCSAFLUSH, &tattr);
  return 0;
}
